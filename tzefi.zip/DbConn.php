<?php
    $conn = new mysqli("localhost", "dror", "CecilCooper15", "tzefi");
?>
